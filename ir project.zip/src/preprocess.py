#import ir_datasets
import re
import nltk
#import os, json
from textblob import Word
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.stem import PorterStemmer
#import string
#nltk.download('wordnet')


# إعداد أدوات المعالجة
stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()
stemmer = PorterStemmer()

def preprocess_text(text):  
    # 1. lowercase
    text = text.lower()

    # 2. إزالة الأرقام
    text = re.sub(r'\d+', '', text)

    # 3. إزالة علامات الترقيم
    text = re.sub(r'[^\w\s]', '', text)

    # 4. إزالة المسافات الزائدة
    text = text.strip()

    # 5. التجزئة
    tokens = word_tokenize(text)

    # 6. حذف كلمات الوقف
    tokens = [t for t in tokens if t not in stop_words]

    # 7. Lemmatization
    tokens = [lemmatizer.lemmatize(t) for t in tokens]
    cleaned = []
    for word in tokens:
        if word not in stop_words:
            corrected = Word(word).correct()      # تصحيح إملائي
            lemmatized = Word(corrected).lemmatize()
            stemmed = stemmer.stem(lemmatized)
            cleaned.append(stemmed)
    return cleaned
