# src/evaluate_marco.py

import os
import json
import ir_datasets
import pytrec_eval

# تحميل مجموعة MSMARCO
print("📥 Loading qrels for MSMARCO...")
dataset = ir_datasets.load("msmarco-passage/train")
full_qrels = dataset.qrels_dict()

# تحميل نتائج البحث التي خزناها
base_dir = os.path.join(os.path.dirname(__file__), '..', 'data')
with open(os.path.join(base_dir, 'msmarco_run.json'), 'r', encoding='utf-8') as f:
    run = json.load(f)

# تصفية qrels فقط للاستعلامات الموجودة في run
qrels = {q_id: full_qrels[q_id] for q_id in run if q_id in full_qrels}

# تحويل القيم إلى float
for q_id in run:
    for doc_id in run[q_id]:
        run[q_id][doc_id] = float(run[q_id][doc_id])

# إعداد المقيم
evaluator = pytrec_eval.RelevanceEvaluator(
    qrels,
    {'map', 'recip_rank', 'P_10'}
)

# تنفيذ التقييم
results = evaluator.evaluate(run)

# حساب المتوسطات
metrics = {'map': 0, 'recip_rank': 0, 'P_10': 0}
for query_id in results:
    for metric in metrics:
        metrics[metric] += results[query_id][metric]

num_queries = len(results)
print("\n📊 Evaluation Metrics for MSMARCO (Sample):")
for metric in metrics:
    value = metrics[metric] / num_queries if num_queries > 0 else 0
    print(f"{metric}: {value:.4f}")
