# src/build_tfidf.py

import json
import os
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy import sparse

# المسارات
base_dir = os.path.join(os.path.dirname(__file__), '..', 'data')
output_dir = base_dir

def load_tokens(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    texts = [' '.join(entry['tokens']) for entry in data]
    return texts

# تحميل نصوص MSMARCO
print("Loading MSMARCO tokens...")
msmarco_docs = load_tokens(os.path.join(base_dir, 'msmarco_docs.json'))
msmarco_queries = load_tokens(os.path.join(base_dir, 'msmarco_queries.json'))

# إنشاء نموذج TF-IDF وتطبيقه على الوثائق
print("Building TF-IDF model...")
vectorizer = TfidfVectorizer()
doc_matrix = vectorizer.fit_transform(msmarco_docs)
query_matrix = vectorizer.transform(msmarco_queries)

# حفظ النموذج
with open(os.path.join(output_dir, 'msmarco_tfidf_vectorizer.pkl'), 'wb') as f:
    pickle.dump(vectorizer, f)

# حفظ المصفوفات
sparse.save_npz(os.path.join(output_dir, 'msmarco_docs_tfidf.npz'), doc_matrix)
sparse.save_npz(os.path.join(output_dir, 'msmarco_queries_tfidf.npz'), query_matrix)

print("✅ TF-IDF representation for MSMARCO saved.")
